import React from 'react';
import './App.css';
import MainLayout from './components/MainLayout.component';

function App() {
	return (
		<div className="App">
			<MainLayout />
		</div>
	);
}

export default App;
